// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
contract IdentityRegistry{
struct Identity{string name;string did;}
mapping(address=>Identity) public identities;
event Registered(address user,string did);
function register(string memory name,string memory did) public {
identities[msg.sender]=Identity(name,did);
emit Registered(msg.sender,did);
}
}